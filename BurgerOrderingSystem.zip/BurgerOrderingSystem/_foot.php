
</main>
    <footer>
        Developed by <b>YANG KAR YIK GROUP</b> &middot;
        Copyrighted &copy; <?= date('Y') ?>
    </footer> 

</body>
</html>